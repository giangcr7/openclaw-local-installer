[CmdletBinding()]
param([Parameter(Position=0)][ValidateSet('install','validate','list','remove')][string]$Command = 'list', [string]$Profile = '', [string[]]$Module = @(), [switch]$DryRun)
$ErrorActionPreference = 'Stop'
$root = if ($env:OPENCLAW_ROOT) { $env:OPENCLAW_ROOT } else { Join-Path $env:USERPROFILE '.openclaw' }
$args = @((Join-Path $root 'module-manager.py'), $Command, '--openclaw-root', $root, '--catalog-root', (Join-Path $root 'module-catalog'), '--skills-source', (Join-Path $root 'module-catalog\skills'))
if ($Profile) { $args += @('--profile', $Profile) }
foreach ($item in $Module) { $args += @('--module', $item) }
if ($DryRun) { $args += '--dry-run' }
& python @args
$status = $LASTEXITCODE
if ($status -eq 0 -and $Command -eq 'install' -and (Get-Command openclaw -ErrorAction SilentlyContinue)) {
  & openclaw gateway restart *> $null
}
exit $status
