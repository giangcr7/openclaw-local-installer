---
name: cai-dat-audio-local-openclaw
description: "Cai dat, van hanh, kiem tra, sua loi hoac rollback toan bo audio cho OpenClaw tren Telegram va Zalo: nhan mic/voice bang faster-whisper local hoac Shared Local STT, xu ly URL voice Zalo zdn.vn AAC, va tra loi bang text kem voice Microsoft Edge TTS. Use cho VPS chinh, VPS rieng hoac member Docker; bao gom backup, dry-run, gioi han pham vi agent/account, test CPU/RAM va bao ve credential."
---

# Cai Dat Audio OpenClaw

Dung mot skill nay cho toan bo luong audio Telegram/Zalo. Khong can goi rieng cac skill cu `openclaw-local-voice-stt`, `openclaw-shared-voice-stt`, `zalo-voice-transcription` hoac `cai-dat-tra-loi-audio-openclaw`.

## Chon Luong

| Nhu cau | Luong can dung |
|---|---|
| Telegram/Zalo gui file voice vao bot | STT local hoac shared |
| Zalo Personal dua vao URL `zdn.vn/*.aac` | Tai URL an toan, sau do goi shared STT |
| Telegram bot tra text kem voice | Microsoft Edge TTS theo agent |
| Van han dich vu faster-whisper dung chung | Dung them skill `shared-local-stt-service` |

Khong bat TTS khi nguoi dung chi can bot hieu mic. Khong them provider STT tra phi khi yeu cau la local/khong ton API.

## Kiem Tra Truoc Khi Sua

1. Doc quy dinh VPS, project note, `AGENTS.md` gan project va checklist production.
2. Xac dinh config that nam tren host, bind mount hay chi nam trong container.
3. Xac dinh dung agent/account Telegram va cac channel dung chung runtime.
4. Chay dry-run, backup config vao `/root/_Backups`, sau do moi apply.
5. Khong in `.env`, token, cookie, credential hoac noi dung transcript.

## Cai STT Cho Member Docker

Uu tien Shared Local STT tren VPS chinh. Voi member co config persistent theo layout chuan, chay dry-run:

```bash
bash /root/.agents/skills/cai-dat-audio-local-openclaw/scripts/install_member_shared.sh \
  --container user-member \
  --member-root /root/Apps/member_vps/docker-users/data/member \
  --member-id member \
  --container-openclaw-home /home/member/.openclaw \
  --dry-run
```

Doi `--dry-run` thanh `--apply` sau khi endpoint health, config path va owner deu dung. Script validate candidate bang CLI cua chinh container va mac dinh chi restart `openclaw-gateway` qua Supervisor; dung `--restart-mode none` de gom nhieu thay doi truoc mot lan restart, hoac `container` chi khi deployment bat buoc. Installer tao client tai `workspace/skills/cai-dat-audio-local-openclaw/scripts/transcribe_shared.py`.

## Cai STT Cho OpenClaw Host

Neu host goi Shared Local STT:

```bash
bash /root/.agents/skills/cai-dat-audio-local-openclaw/scripts/install_host_shared.sh \
  --openclaw-home /root/.openclaw \
  --member-id openclaw-main \
  --dry-run
```

Neu VPS doc lap va can model local:

```bash
bash /root/.agents/skills/cai-dat-audio-local-openclaw/scripts/install_standalone_local.sh \
  --openclaw-home /root/.openclaw \
  --dry-run
```

Installer standalone tao venv trong `<openclaw-home>/tools/local-stt-venv`, warm model `small`, va cau hinh CLI local. Lan dau can Internet; sau khi model da cache co the phien am offline.

## Xu Ly Voice URL Zalo

Khi plugin `zalouser` dua vao mot URL HTTPS `zdn.vn` ket thuc bang `.aac` thay vi media attachment, chay:

```bash
python3 /root/.openclaw/workspace/skills/cai-dat-audio-local-openclaw/scripts/transcribe_zalo_voice.py '<URL_VOICE_ZALO>'
```

Script chi chap nhan `zdn.vn` va subdomain, gioi han 25 MB, dung thu muc tam, goi client shared cung skill va xoa audio sau khi xong. Dung stdout lam noi dung nguoi dung da noi; khong tra lai URL neu phien am thanh cong.

### Sửa lỗi monitor không chuyển voice Zalo vào STT

Nếu bot vẫn trả lời “chưa có công cụ chuyển AAC thành văn bản” dù Shared STT
health tốt, lỗi nằm trước bước STT: monitor `@openclaw/zalouser` chưa đưa URL
voice inbound vào `message.content`. Với Docker member, xử lý như sau:

1. Xác định bundle đang được mount trong
   `<member-data>/.openclaw/npm/projects/*/node_modules/@openclaw/zalouser/dist/`;
   chỉ sửa `monitor-*.js` và `zalo-js-*.js` đang được Gateway nạp.
2. Trong normalizer, trích các URL HTTPS từ `data` có host Zalo voice
   (`zdn.vn`, `flchat.vn`, `dlfl.vn`) và đuôi `.aac`, `.m4a` hoặc `.mp3`, tối đa
   hai URL; nối URL vào inbound content bằng marker nội bộ.
3. Trong monitor trước agent dispatch, gọi
   `workspace/skills/cai-dat-audio-local-openclaw/scripts/transcribe_zalo_voice.py`
   bằng `execFile("python3", [script, url])`, không dùng shell interpolation.
   Giới hạn một voice/lượt, timeout khoảng 190 giây, output tối đa 12.000 bytes;
   thay URL bằng transcript tối đa 6.000 ký tự.
4. Khi phiên âm lỗi, giữ nguyên body và ghi log bounded như
   `voice transcription failed`; tuyệt đối không ghi signed URL, token hay nội
   dung audio vào log.

Trước patch phải backup config và hai bundle vào
`/root/_Backups/<member>-zalo-voice-intake/<UTC timestamp>/`. Chạy `node --check`
cho cả hai bundle, `openclaw config validate`, restart đúng Gateway Supervisor,
đợi channel probe báo `Zalo linked/running/connected`, rồi quét log startup.
Không coi việc Gateway connected là đã test voice; cần một voice test được owner
cho phép để xác nhận log `zalouser-audio` và transcript. Rollback bằng cách khôi
phục hai bundle từ backup, validate rồi restart Gateway.

## Bat Bot Tra Loi Bang Voice

Voi config tren host, giu TTS global `off` va chi bat agent Telegram can dung:

```bash
bash /root/.agents/skills/cai-dat-audio-local-openclaw/scripts/enable_edge_tts_agent.sh \
  --config /root/.openclaw/openclaw.json \
  --agent main \
  --voice vi-VN-NamMinhNeural \
  --auto-mode inbound \
  --dry-run
```

Voi member legacy co config that trong container:

```bash
bash /root/.agents/skills/cai-dat-audio-local-openclaw/scripts/enable_edge_tts_container.sh \
  --container user-member \
  --config-path /home/member/.openclaw/openclaw.json \
  --agent main \
  --auto-mode inbound \
  --dry-run
```

- `inbound`: chi tra voice khi input la voice.
- `always`: ca input chu va voice deu tra text kem voice.
- Giong nam: `vi-VN-NamMinhNeural`.
- Giong nu: `vi-VN-HoaiMyNeural`.
- Neu runtime co nhieu agent/channel, khong bat `always` toan cuc.
- OpenClaw `2026.8.1+` dung `tts` o top-level va `agents.entries.<id>.tts`; khong ghi schema cu `messages.tts` hoac `agents.list`.

Doc `references/telegram-scope.md` truoc khi bat TTS tren runtime dung chung Telegram va Zalo.

## Kiem Tra

Chay cac test phu hop, khong gui tin that neu chua duoc phep:

```bash
curl -fsS http://172.17.0.1:18080/health
python3 /root/.openclaw/workspace/skills/cai-dat-audio-local-openclaw/scripts/transcribe_shared.py /path/to/audio.ogg
/root/.openclaw/tools/local-stt-venv/bin/python \
  /root/.openclaw/workspace/skills/cai-dat-audio-local-openclaw/scripts/transcribe_local.py \
  /path/to/audio.ogg
```

Sau apply:

1. Validate `openclaw.json` bang CLI cua runtime.
2. Respawn/restart dung gateway, khong mac dinh restart ca container legacy.
3. Kiem tra startup log, Telegram/Zalo channel status va Microsoft plugin neu dung TTS.
4. Test bang fixture audio noi bo; chi test mic that khi duoc phep.
5. Xac nhan bot/channel khac khong bi bat TTS ngoai y muon.

## Gioi Han Tai Nguyen

- Audio STT mac dinh toi da 20 MB va 10 phut; Zalo URL toi da 25 MB truoc khi gui STT.
- Local STT dung `faster-whisper small`, CPU INT8, bon CPU threads va mot transcription dong thoi.
- `400% CPU` cua process tuong duong bon core; model thuong can khoang 500-1000 MB RSS tuy may.
- Shared service giu `CPUQuota=400%`, `MemoryMax=3G`, mot worker va queue toi da 20 tru khi da benchmark lai.
- Metrics chi ghi thoi gian, CPU/RAM va do dai transcript; khong ghi noi dung noi.

## Rollback

- Khoi phuc `openclaw.json` va credential tu backup, validate, sau do restart/respawn gateway bang cach dang dung cua runtime.
- Voi TTS, khoi phuc config va xac nhan text reply van hoat dong.
- Co the giu venv/model cache de rollback nhanh; khong xoa audio, transcript, model hoac credential neu chua co yeu cau ro.
- Neu token shared bi lo, dung quy trinh rotate trong skill `shared-local-stt-service`; khong in token ra terminal/log.

Chi tiet kien truc va validation xem `references/architecture.md`.


## Zalo voice intake repair (managed 2026-09-27)

When Zalo receives a voice message but the agent says STT is unavailable, first run the local STT client against the saved audio. If transcription succeeds, the failure is the Zalo monitor intake path: it did not pass the signed voice URL to `transcribe_zalo_voice.py`.

Use `scripts/patch_zalo_voice_intake.py --monitor <active-monitor.mjs> --dry-run` before editing. The active bundle is the newest `@openclaw/zalouser/dist/.setup/monitor-*.mjs` under the member `.openclaw/npm/projects/` tree. Apply only after a root-only backup, then run `node --check` on the monitor and adjacent `zalo_voice_intake.mjs`, `openclaw config validate`, and restart only the Supervisor-owned Gateway. The patch extracts only HTTPS voice URLs from `zdn.vn`, `flchat.vn`, or `dlfl.vn`, calls the existing local STT helper with a bounded timeout, replaces the inbound body with the transcript, and logs only success/failure markers.

Do not claim the audio was understood from Gateway connectivity alone. A successful fixture STT run plus a real owner voice test must produce a `[zalouser-audio] transcription ok` log marker and a transcript in the agent turn. Roll back the exact monitor and helper from the timestamped backup if startup or voice handling regresses.
