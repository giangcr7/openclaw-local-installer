---
name: openclaw-9router-overload-recovery
description: Diagnose, install, verify, repair, or roll back the reliable local proxy used when OpenClaw agents receive HTTP 200/SSE responses whose assistant text contains an upstream overload or generic processing-error message. Use for repeated 9Router/Codex error replies, missing retry on successful HTTP responses, Codex account concentration, or model fallback hardening for one agent or all agents on the main VPS.
---

# OpenClaw 9Router Overload Recovery

Recover transient AI failures without forwarding raw upstream error text to Telegram. The proxy recognizes capacity, overload, structured failure, model-not-found, and the exact processing-error template. Named combos are read from SQLite and tried in their exact component order for both Chat Completions and Responses.

## Paths and services

- Project: `/root/Automation/9router/reliable_chat_proxy`
- Proxy service: `openclaw-9router-reliable-proxy.service`
- Upstream 9Router: `http://127.0.0.1:20128`
- Reliable proxy: `http://127.0.0.1:20129`
- OpenClaw config: `/root/.openclaw/openclaw.json`
- 9Router database: `/root/.9router/db/data.sqlite`
- Backups: `/root/_Backups/<timestamp>_openclaw_9router_overload_recovery`

## Safety

- Read the VPS Second AI Brain files and production checklist before changes.
- Obtain explicit authorization before production restart or configuration mutation.
- Never print provider credentials, Telegram tokens, prompts, private messages, or full request bodies.
- Back up `openclaw.json`, the 9Router SQLite database with the SQLite backup API, and affected systemd units.
- Do not call Telegram `getUpdates` while Gateway is running and do not send a real test message without authorization.
- Keep the proxy on loopback. Do not expose port `20129` publicly; if remote member clients need protection, route the existing TLS ingress through the loopback proxy.

## Diagnose

Prove all of the following before applying this recovery:

- OpenClaw transcript contains the exact overload assistant text.
- Provider/model metadata points to the intended 9Router route.
- The transport returned HTTP `200` and `text/event-stream`, so ordinary error fallback did not run.
- Telegram polling, routing, Gateway, CPU, and RAM are healthy.
- Redacted 9Router usage data shows the downstream provider/model and account distribution.
- For model availability failures, check for HTTP `404` with error code `model_not_found`; this is a fallback-triggering condition, not a reason to expose the raw upstream error to OpenClaw.

The proxy intentionally matches only these normalized assistant responses: the known overload variants, `Service temporarily unavailable`, or the complete generic processing-error template with a valid request UUID. Do not broaden the match to arbitrary words such as `error`, because a legitimate assistant answer can contain them.

Successful `text/event-stream` responses are streamed progressively after safe output; lifecycle events and possible error prefixes remain buffered. Once real output/tool calls are sent, a later failure cannot be replayed safely and is logged without duplicating the request. Client disconnects abort the active upstream fetch. Non-streaming responses and upstream statuses remain buffered for classification.

## Dry run

```bash
cd /root/Automation/9router/reliable_chat_proxy
npm test
python3 -m unittest -v test_configure_openclaw.py
python3 -m py_compile configure_9router_routing.py configure_openclaw.py
python3 configure_9router_routing.py
python3 configure_openclaw.py --all-agents
systemd-analyze --user verify openclaw-9router-reliable-proxy.service
```

Dry-run output must show only provider strategy, combo model IDs, local proxy URL, target agent, and model aliases. It must not show API keys.

## Apply

Create a restrictive backup directory first, then run:

```bash
python3 configure_9router_routing.py \
  --apply \
  --backup-dir /root/_Backups/<incident-directory>

install -m 644 openclaw-9router-reliable-proxy.service \
  /root/.config/systemd/user/openclaw-9router-reliable-proxy.service
systemctl --user daemon-reload
systemctl --user restart 9router.service
systemctl --user enable --now openclaw-9router-reliable-proxy.service

python3 configure_openclaw.py --all-agents \
  --apply \
  --backup-dir /root/_Backups/<incident-directory>
openclaw config validate
systemctl --user restart openclaw-gateway.service
```

The reliable proxy reads `/root/.9router/db/data.sqlite` read-only with a 30-second refresh. Named combos use their exact component IDs, with `COMBO_MAX_ATTEMPTS=20` as a safety ceiling; direct non-combo calls retain `MAX_ATTEMPTS=3` legacy behavior. Nginx `codex.anhlaptrinh.vn` API locations `/v1` and `/v1/` point to `20129`; dashboard `/` remains on `8870`.

For a single-agent repair, omit `--all-agents` and pass `--agent <agent-id>`.

## Validate

```bash
curl -fsS http://127.0.0.1:20128/api/health
curl -fsS http://127.0.0.1:20129/health
systemctl --user is-active \
  9router.service \
  openclaw-9router-reliable-proxy.service \
  openclaw-gateway.service
openclaw config validate
openclaw channels status --channel telegram --probe --json
journalctl --user -u openclaw-9router-reliable-proxy.service --since "15 minutes ago" -o cat --no-pager
```

Confirm one post-change request uses provider `9rr`, proxy logs `upstream_stream_complete`, `upstream_complete`, or `upstream_retry`, and the exact overload and generic processing-error sentences are absent from new transcript events. Confirm the client receives a normal SSE chunk before upstream `[DONE]`. Do not send a real Telegram test without authorization.

For all-agent changes, also confirm every explicit `agents.entries.*.model` source reference is either `9rr/` or intentionally external, and default text/image models use `9rr/` where they previously used `9r/`.

## Input and output

- Input: OpenAI-compatible `POST /v1/chat/completions` and `POST /v1/responses`; other paths are passed through.
- Output: the first successful non-overload, non-processing-error upstream response.
- Retry order: named combo component IDs exactly as stored in `combos`; direct non-combo calls use requested model, one retry, then configured fallbacks.
- Exhaustion: return a sanitized HTTP `503` JSON error; never forward raw overload or generic processing-error assistant text or request IDs.
- Logs: structured metadata only: timestamp, event, attempt, model, status, duration, retry reason. Never log prompt or credentials.

## Rollback

Restore only this incident's files and database backup:

```bash
systemctl --user stop openclaw-gateway.service
systemctl --user disable --now openclaw-9router-reliable-proxy.service
systemctl --user stop 9router.service
install -m 600 /root/_Backups/<incident-directory>/openclaw.json.before \
  /root/.openclaw/openclaw.json
install -m 600 /root/_Backups/<incident-directory>/9router-data.sqlite.before \
  /root/.9router/db/data.sqlite
systemctl --user start 9router.service
systemctl --user start openclaw-gateway.service
openclaw config validate
```

Restore SQLite only while 9Router is stopped. Preserve unrelated later configuration changes; if the incident is old, use a targeted reverse patch instead of copying the whole old config.

After an important change, update `/root/_Second_AI_Brain/06_Nhat_Ky_Thay_Doi.md`.

## Timeout upstream — 2026-09-21

- Reliable proxy mặc định và user unit dùng `REQUEST_TIMEOUT_MS=300000` (300 giây) để không cắt sớm tác vụ PDF/tài liệu nặng.
- Nguồn cấu hình: `/root/Automation/9router/reliable_chat_proxy/server.mjs` và `/root/Automation/9router/reliable_chat_proxy/openclaw-9router-reliable-proxy.service`; user unit active nằm tại `/root/.config/systemd/user/openclaw-9router-reliable-proxy.service`.
- Nginx `9router.anhlaptrinh.vn` giữ `proxy_read_timeout/proxy_send_timeout=3600s` và route qua `127.0.0.1:20129`.
- Khi thay đổi timeout, backup user unit, source unit, `server.mjs`, 9Router SQLite và OpenClaw config; chạy `npm test`, `node --check`, `systemd-analyze --user verify`, restart riêng proxy rồi kiểm tra `/health`.
