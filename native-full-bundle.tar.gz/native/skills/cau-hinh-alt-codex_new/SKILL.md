---
name: cau-hinh-alt-codex
description: Cài đặt, sửa hoặc đổi đồng bộ model Codex Extension/Codex CLI và OpenClaw qua ALT/9Router trên Windows, Linux, macOS hoặc VPS. Use khi cần cài Codex trong Antigravity, bắt lỗi 401 hoặc request `/v1/responses` thiếu Authorization, bắt buộc `requires_openai_auth = true` cho custom provider, xác minh OPENAI_API_KEY/auth.json và đúng CODEX_HOME, chạy test thật bằng `codex exec`, chọn GPT-5.6-sol/GPT-5.6-terra/GPT-5.6-luna/GPT-6-astra, khắc phục lỗi "The extension couldn't load its resources", phân loại Webview timeout/CSP với app-server hoặc plugin manifest, đổi model OpenClaw, backup config hoặc xử lý provider/model mà không làm lộ API key.
---

# Cấu Hình Codex Qua ALT Gateway Đa Nền Tảng

## Mục Tiêu

Cấu hình Codex Extension trong Antigravity và Codex CLI trên máy khác theo mẫu đang dùng trên VPS:

```toml
model_provider = "router"
model = "GPT-5.6-sol"
model_reasoning_effort = "xhigh"
preferred_auth_method = "apikey"
cli_auth_credentials_store = "file"

[model_providers.router]
name = "router"
base_url = "https://codex.anhlaptrinh.vn/v1"
wire_api = "responses"
requires_openai_auth = true
# For Extension auth, use auth.json below; do not replace it with ALT_KEY.
# If an environment-only CLI provider is explicitly required, use:
# env_key = "OPENAI_API_KEY"
```

`requires_openai_auth = true` là cờ bắt buộc với custom provider `router`. Cờ này yêu cầu Codex nạp credential OpenAI từ `auth.json` và đính kèm header `Authorization` khi gọi `/v1/responses`; chỉ có `preferred_auth_method = "apikey"` và `cli_auth_credentials_store = "file"` vẫn chưa đủ trên Codex CLI v0.151.0 nếu thiếu cờ này.

Trường hợp cấu hình Codex Extension: credential canonical là khóa `OPENAI_API_KEY` trong `auth.json` (hai file `auth.json` và `config.toml` luôn nằm cùng folder với `SKILL.md`) rồi copy trực tiếp vào `CODEX_HOME` (`%USERPROFILE%\.codex` hoặc `$CODEX_HOME`). Không coi `ALT_KEY` là alias của `OPENAI_API_KEY`, không đặt API key vào `config.toml`, và không hoàn tất cài đặt nếu preflight chưa xác nhận key với gateway.

## Preflight Bắt Buộc Khi Cài Extension

Lỗi `401 Unauthorized: {"error":"API key required for remote API access"}` nghĩa là request remote không có bearer key. Với Antigravity, ba nguyên nhân cần chặn trước khi copy là:

1. `auth.json` nguồn hoặc đích thiếu khóa `OPENAI_API_KEY`, rỗng hoặc còn placeholder.
2. Extension chạy bằng `CODEX_HOME`/tài khoản khác với nơi đã copy credential, không ép `cli_auth_credentials_store = "file"`, hoặc workflow chỉ đặt `ALT_KEY` trong shell; khi đó app-server không đọc đúng `auth.json` và Codex không xem `ALT_KEY` là `OPENAI_API_KEY`.
3. `[model_providers.<provider>]` thiếu `requires_openai_auth = true`; gateway và API key vẫn có thể hoạt động khi test bằng `curl`, nhưng chính Codex không nạp key và gửi request `/v1/responses` không có header `Authorization`.

Không chẩn đoán bằng cách in key. Luôn chạy script preflight/cài đặt đi kèm skill; script sẽ resolve đường dẫn, kiểm tra JSON/TOML, gọi `base_url + /models` và kiểm tra auth trên `/responses` bằng key trong bộ nhớ, rồi mới backup/copy:

```bash
skill_dir="<thư-mục-chứa-SKILL.md>"
codex_home="${CODEX_HOME:-$HOME/.codex}"
python3 "$skill_dir/scripts/install_extension_config.py" \
  --source-dir "$skill_dir" \
  --target-dir "$codex_home"
```

Script dừng trước khi ghi nếu thiếu key, thiếu `requires_openai_auth = true`, `/models` hoặc `/responses` trả `401`, `CODEX_HOME` không hợp lệ hoặc config sai. Probe `/responses` gửi body rỗng nên HTTP `400`/`422` được xem là xác thực đã qua và không phát sinh lượt model. Nếu máy tạm thời không có mạng, chỉ được dùng `--skip-gateway-check` để kiểm tra/copy ngoại tuyến; phải chạy lại preflight có gateway trước khi báo hoàn tất. Trên Windows PowerShell, dùng cùng script với `python` và truyền `$sourceDir`, `$codexHome` đã resolve bằng `Resolve-Path`/`$env:CODEX_HOME`.

Sau copy, kiểm tra lại `auth.json` đích có `OPENAI_API_KEY` không rỗng (chỉ báo `present/missing`), kiểm tra `codex login status`, rồi thoát hoàn toàn và mở lại Antigravity. Không chỉ reload cửa sổ khi app-server còn giữ `CODEX_HOME` cũ. Sau khi app-server mới đã nạp config, bắt buộc chạy một request thật bằng `codex exec`; probe HTTP trực tiếp chưa chứng minh chính Codex đã gửi header auth.

## Checklist Bắt Buộc Trước Khi Báo Hoàn Tất

- [ ] `config.toml` đích có đúng custom provider đang được chọn, `wire_api = "responses"` và `requires_openai_auth = true` trong cùng block `[model_providers.<provider>]`.
- [ ] `preferred_auth_method = "apikey"`, `cli_auth_credentials_store = "file"`, và `auth.json` trong đúng `CODEX_HOME` có `OPENAI_API_KEY` không rỗng; chỉ báo trạng thái `present/missing`, không in giá trị.
- [ ] `scripts/install_extension_config.py` chạy đạt mà không dùng `--skip-gateway-check`; cả `/models` và kiểm tra auth `/responses` đều không trả `401`.
- [ ] Đã thoát hoàn toàn Antigravity/Codex app-server cũ hoặc dừng đúng PID đã xác minh, sau đó mở lại để nạp config mới; không dùng `pkill -f codex` mặc định.
- [ ] Đã chạy test thật bằng Codex, ví dụ `codex exec "Viết 1 câu chào ngắn gọn"`, và nhận phản hồi model thành công.
- [ ] Log/request mới nhất xác nhận `/v1/responses` không còn `401` và không còn dấu hiệu request thiếu `Authorization`; không in header hoặc token trong báo cáo.

Không đánh dấu hoàn tất nếu mới chỉ gọi `curl /v1/models`, tự POST `/v1/responses`, nhìn thấy API key trong `auth.json`, hoặc sửa file mà chưa chạy `codex exec`. Các bước đó kiểm tra gateway/credential/config riêng lẻ nhưng chưa chứng minh app-server Codex đã nạp và gửi credential.

## Quy Tắc Đường Dẫn Mềm

- Không giả định VPS chạy bằng `root`, không ghi cứng tên user, ổ đĩa, thư mục cài skill hoặc thư mục backup.
- Luôn ưu tiên biến môi trường/tùy chọn do người dùng cung cấp, sau đó mới dùng thư mục home của user đang chạy.
- Thư mục skill là thư mục thực tế chứa `SKILL.md`; dùng `<skill-dir>`, biến `ALT_CODEX_SKILL_DIR` hoặc working directory đã được xác minh thay vì chép một đường dẫn máy cụ thể.
- Codex config mặc định: `${CODEX_HOME:-$HOME/.codex}/config.toml` trên shell; trên PowerShell dùng `$env:CODEX_HOME` nếu có, nếu không dùng `Join-Path $env:USERPROFILE ".codex"`.
- OpenClaw config mặc định: `${OPENCLAW_CONFIG_PATH:-$HOME/.openclaw/openclaw.json}`. Khi layout khác, lấy đường dẫn thực tế từ người dùng hoặc config/runtime hiện tại.
- Backup mặc định của script: `${ALT_CODEX_BACKUP_DIR:-${XDG_STATE_HOME:-$HOME/.local/state}/cau-hinh-alt-codex/backups}`; có thể ghi đè bằng `ALT_CODEX_BACKUP_DIR` hoặc `--backup-dir`.
- Trước khi đọc, copy hoặc sửa file, luôn hiển thị/xác minh đường dẫn đã resolve và dừng nếu file nằm ngoài tài khoản hoặc VPS mục tiêu.

## Model Được Hỗ Trợ

Skill hỗ trợ bốn model sau:

- `GPT-5.6-sol`: model mặc định khi người dùng không yêu cầu model cụ thể.
- `GPT-5.6-terra`: dùng khi người dùng yêu cầu model này hoặc một cách viết tương đương.
- `GPT-5.6-luna`: dùng khi người dùng yêu cầu model này hoặc một cách viết tương đương.
- `GPT-6-astra`: dùng khi người dùng yêu cầu model này hoặc một cách viết tương đương.

Nhận diện tên model không phân biệt chữ hoa/chữ thường. Chấp nhận dấu gạch ngang hoặc khoảng trắng giữa các phần của tên model, đồng thời bỏ khoảng trắng thừa trước khi so khớp. Ví dụ:

- `GPT-5.6-luna`, `gpt-5.6-luna`, `GPT-5.6-LUNA` và `gpt 5.6 luna` đều phải được hiểu là `GPT-5.6-luna`.
- `GPT-5.6-terra`, `gpt-5.6-terra` và `gpt 5.6 terra` đều phải được hiểu là `GPT-5.6-terra`.
- `GPT-5.6-sol`, `gpt-5.6-sol` và `gpt 5.6 sol` đều phải được hiểu là `GPT-5.6-sol`.
- `GPT-6-astra`, `gpt-6-astra` và `gpt 6 astra` đều phải được hiểu là `GPT-6-astra`.

Sau khi nhận diện, luôn chuẩn hóa và ghi tên chính thức vào `config.toml`: `GPT-5.6-sol`, `GPT-5.6-terra`, `GPT-5.6-luna` hoặc `GPT-6-astra`. Không ghi nguyên cách viết chữ thường hoặc cách viết có khoảng trắng của người dùng vào file.

Khi người dùng yêu cầu `GPT-5.6-terra`, `GPT-5.6-luna`, `GPT-6-astra` hoặc cách viết tương đương, cập nhật khóa `model` trong `config.toml` thành tên chính thức tương ứng. Nếu dùng bộ file mẫu đi kèm skill, copy file theo workflow rồi chỉ đổi khóa `model`, không thay đổi các cấu hình không liên quan.

Nếu người dùng yêu cầu bất kỳ model nào ngoài bốn model trên, không cập nhật cấu hình và không tự động thay thế bằng model gần giống. Hãy thông báo rằng hiện tại chỉ hỗ trợ `GPT-5.6-sol`, `GPT-5.6-terra`, `GPT-5.6-luna` và `GPT-6-astra`, rồi yêu cầu họ chọn một trong bốn model này.

## Chính Sách Chọn Model

- `GPT-5.6-sol`: mặc định cân bằng cho coding/agent phức tạp; dùng khi người dùng không chỉ định model.
- `GPT-5.6-terra`: lựa chọn cân bằng tốc độ và chất lượng cho công việc hằng ngày.
- `GPT-5.6-luna`: ưu tiên tốc độ và chi phí cho tác vụ nhẹ.
- `GPT-6-astra`: model reasoning cao cấp cho workflow cần suy luận sâu; chỉ chọn khi người dùng yêu cầu hoặc cấu hình hiện tại đã dùng model này.
- Codex ghi model dạng `GPT-5.6-*`.
- OpenClaw dùng provider/model dạng `<provider-hien-tai>/GPT-5.6-*`. Prefix provider có thể là `9r`, `9k`, `8r`, `8k` hoặc tên khác; phải đọc cấu hình hiện tại, không được hardcode.
- Khi cài mới, sửa provider hoặc đồng bộ VPS/OpenClaw, xác minh model xuất hiện trong endpoint `/v1/models` của gateway đang dùng. Riêng yêu cầu chỉ đổi model trên máy tính thì không test gateway trừ khi người dùng yêu cầu.

## Chỉ Đổi Model Trên Máy Tính

Áp dụng workflow này khi người dùng chỉ yêu cầu đổi model Codex trên máy tính, ví dụ “đổi sang GPT-5.6-terra”, mà không yêu cầu đồng bộ VPS, đổi OpenClaw, copy bộ file mẫu, đổi API key hoặc kiểm tra gateway.

1. Chuẩn hóa model theo mục **Model Được Hỗ Trợ**. Nếu model không nằm trong bốn model được hỗ trợ, dừng trước khi sửa file.
2. Resolve `config.toml` của user hiện tại bằng `$CODEX_HOME` hoặc thư mục `.codex` trong home; không dùng file `config.toml` nằm cạnh `SKILL.md` nếu người dùng không yêu cầu copy bộ file mẫu.
3. Backup `config.toml` hiện tại với timestamp trước khi ghi nếu file đã tồn tại.
4. Chỉ cập nhật khóa top-level `model` thành tên chính thức `GPT-5.6-sol`, `GPT-5.6-terra`, `GPT-5.6-luna` hoặc `GPT-6-astra`; giữ nguyên `model_provider`, `model_reasoning_effort`, `[model_providers.*]`, `[projects.*]`, MCP và mọi cấu hình khác.
5. Không đọc/sửa `auth.json`, không copy file, không sửa OpenClaw, không restart gateway/Antigravity và không test `/v1/models` trừ khi người dùng yêu cầu riêng.
6. Sau khi ghi, chỉ xác nhận `config.toml` tồn tại và khóa `model` đã nhận đúng giá trị; báo cáo đường dẫn thực tế và model mới, không in secret.

Ví dụ resolve và sửa trực tiếp trên Linux/macOS/VPS:

```bash
codex_home="${CODEX_HOME:-$HOME/.codex}"
config_path="$codex_home/config.toml"
selected_model="GPT-5.6-terra"
stamp=$(date +%Y%m%d-%H%M%S)

test -f "$config_path" || { echo "Không tìm thấy: $config_path" >&2; exit 1; }
cp -p "$config_path" "$config_path.bak-$stamp"
MODEL_VALUE="$selected_model" perl -0pi -e 's/^model\s*=\s*"[^"]*"/model = "$ENV{MODEL_VALUE}"/m or die "Top-level model key not found\n"' "$config_path"
```

Trên Windows PowerShell, resolve `$codexHome` từ `$env:CODEX_HOME` hoặc `$env:USERPROFILE`, tạo backup rồi sửa duy nhất dòng top-level `model` trong `$configPath`. Không thay `$sourceDir`, không copy `auth.json` và không dùng đường dẫn máy cụ thể.

## Đổi Đồng Bộ Trên VPS

Script chuẩn đi kèm skill:

```bash
bash scripts/set_alt_model.sh --model GPT-5.6-sol --dry-run
bash scripts/set_alt_model.sh --model GPT-5.6-sol --all-agents
```

Nếu gọi từ thư mục khác, truyền thư mục skill bằng biến thay vì ghi cứng đường dẫn cài đặt:

```bash
export ALT_CODEX_SKILL_DIR="<skill-dir>"
bash "$ALT_CODEX_SKILL_DIR/scripts/set_alt_model.sh" \
  --model GPT-5.6-sol \
  --all-agents
```

Script thực hiện:

1. Chỉ chấp nhận `GPT-5.6-sol`, `GPT-5.6-terra`, `GPT-5.6-luna`, `GPT-6-astra` và cách viết tương đương.
2. Backup file vào `${ALT_CODEX_BACKUP_DIR:-${XDG_STATE_HOME:-$HOME/.local/state}/cau-hinh-alt-codex/backups}` trước khi ghi; cho phép đổi bằng `ALT_CODEX_BACKUP_DIR` hoặc `--backup-dir`.
3. Chỉ đổi khóa `model` cấp cao trong Codex config; giữ nguyên provider, projects, MCP và cấu hình khác.
4. Tự phát hiện provider từ `agents.defaults.model.primary`, xác nhận provider đó tồn tại trong `models.providers`, rồi đăng ký đủ bốn model vào đúng provider.
5. Đổi `agents.defaults.model.primary` và thêm model vào `agents.defaults.models`.
6. Khi có `--all-agents`, chỉ thay các agent đang ghim `codex` hoặc một trong bốn model được quản lý thuộc đúng provider vừa phát hiện; không đụng agent dùng provider khác.
7. Validate JSON/OpenClaw sau khi ghi; nếu validation lỗi thì khôi phục backup vừa tạo.
8. Tự động chạy `openclaw gateway restart` và kiểm tra `openclaw gateway status` sau khi sửa config OpenClaw đang hoạt động.

Mặc định script dùng:

- Codex: `${CODEX_HOME:-$HOME/.codex}/config.toml`
- OpenClaw: `${OPENCLAW_CONFIG_PATH:-$HOME/.openclaw/openclaw.json}`
- Backup: `${ALT_CODEX_BACKUP_DIR:-${XDG_STATE_HOME:-$HOME/.local/state}/cau-hinh-alt-codex/backups}`

Có thể chỉ định đường dẫn khác bằng `--codex-config`, `--openclaw-config`, `--backup-dir` hoặc các biến môi trường tương ứng ở trên.

Khi đổi model OpenClaw, gateway sẽ restart tự động sau bước validate. Chỉ dùng tùy chọn dưới đây khi cần chủ động trì hoãn restart:

```bash
bash scripts/set_alt_model.sh \
  --model GPT-5.6-terra \
  --openclaw-only \
  --no-restart-gateway
```

Với `--dry-run`, script chỉ hiển thị rằng gateway sẽ restart và không thực hiện restart.

Script ưu tiên lấy prefix từ model mặc định hiện tại. Ví dụ:

- `9r/codex` sẽ đổi thành `9r/GPT-5.6-sol`.
- `9k/codex` sẽ đổi thành `9k/GPT-5.6-sol`.
- `8r/GPT-5.6-luna` sẽ đổi thành `8r/GPT-5.6-terra` khi chọn terra.
- `8k/codex` sẽ đổi thành `8k/GPT-5.6-luna` khi chọn luna.

Nếu cấu hình không có model mặc định hợp lệ hoặc có nhiều provider không thể xác định duy nhất, script phải dừng và yêu cầu chỉ rõ provider, không được tự đoán:

```bash
bash scripts/set_alt_model.sh \
  --model GPT-5.6-sol \
  --openclaw-provider 9k \
  --all-agents
```

### Chỉ đổi Codex

```bash
bash scripts/set_alt_model.sh --model GPT-5.6-terra --codex-only
```

### Chỉ đổi OpenClaw

```bash
bash scripts/set_alt_model.sh --model GPT-5.6-luna --openclaw-only --all-agents
```

### Kiểm tra sau thay đổi

```bash
codex_config="${CODEX_HOME:-$HOME/.codex}/config.toml"
rg -n '^(model_provider|model|model_reasoning_effort)\s*=' "$codex_config"
openclaw config validate
openclaw models status
```

Không in `auth.json`, API key hoặc toàn bộ `openclaw.json` trong báo cáo.

## Khi Dùng Skill

- Cài Codex Extension trong Antigravity trên Windows, Linux hoặc macOS để chạy qua ALT Gateway.
- Đồng bộ cách cấu hình từ user config Codex trên VPS sang máy khác.
- Sửa lỗi provider, model, endpoint, biến môi trường hoặc lỗi `401`/không kết nối.
- Cấu hình Codex CLI và extension dùng chung user-level config.
- Đổi model giữa `GPT-5.6-sol`, `GPT-5.6-terra`, `GPT-5.6-luna` và `GPT-6-astra` theo yêu cầu của người dùng.
- Khi người dùng chỉ nói đổi model trên máy tính, sửa trực tiếp khóa `model` trong user `config.toml` theo mục **Chỉ Đổi Model Trên Máy Tính**.
- Đổi cùng một model cho Codex và OpenClaw trên VPS, bao gồm các agent đang ghim model cũ khi người dùng yêu cầu áp dụng toàn bộ.

## Quy Tắc An Toàn

- Không đọc hoặc in toàn bộ file cấu hình nếu file có thể chứa secret; chỉ lấy các khóa cần thiết và che giá trị nhạy cảm.
- Không ghi API key thật vào skill, tài liệu, repo, shell history hoặc câu trả lời cuối.
- Với bộ file cài Extension, credential phải nằm ở `auth.json` dưới khóa `OPENAI_API_KEY`; không thay bằng khóa JSON `ALT_KEY`.
- Nếu dùng `env_key` cho workflow CLI riêng, giá trị phải là tên biến `OPENAI_API_KEY`, tuyệt đối không phải API key thật; không dùng `ALT_KEY` trong cấu hình chuẩn của skill này.
- Luôn backup `config.toml` trước khi sửa nếu file đã tồn tại.
- Luôn backup `openclaw.json` trước khi sửa và chạy `openclaw config validate` sau thay đổi.
- Không đổi `imageModel`, fallback hoặc provider khác nếu người dùng chỉ yêu cầu đổi model chat mặc định.
- Không ghi đè các phần cấu hình khác như `[projects]`, MCP, sandbox hoặc trust nếu task không yêu cầu.
- Không yêu cầu người dùng gửi API key vào chat. Cho người dùng tự nhập trực tiếp trên máy.

## Vị Trí Cấu Hình

| Môi trường | Cách resolve user config |
|---|---|
| Windows PowerShell | Dùng `$env:CODEX_HOME` nếu có; nếu không, ghép `$env:USERPROFILE`, `.codex` và `config.toml` bằng `Join-Path` |
| Linux/macOS/VPS | `${CODEX_HOME:-$HOME/.codex}/config.toml` |

VPS chạy user nào thì dùng home của user đó; không thay `$HOME` bằng một home directory cố định. Nếu có `CODEX_HOME`, ưu tiên thư mục đó. Extension và CLI phải chạy dưới cùng tài khoản người dùng để đọc cùng cấu hình và biến môi trường.

## Sao Chép Bộ File Mẫu & Xử Lý API Key Cho Extension

> [!IMPORTANT]
> Hai file `auth.json` và `config.toml` **luôn nằm cùng folder với `SKILL.md`** trong thư mục của skill. Khi tham chiếu hay copy, luôn lấy trực tiếp từ cùng thư mục chứa `SKILL.md`.

Trường hợp cấu hình Codex Extension, khi API key đã được người dùng nhập trực tiếp trên máy đích hoặc đã có sẵn trong file nguồn được cấp quyền:
1. Cập nhật API key vào file `auth.json` tại thư mục skill (luôn nằm cùng folder với `SKILL.md`):
   ```json
   {
     "OPENAI_API_KEY": "<API_KEY>"
   }
   ```
2. Chạy `scripts/install_extension_config.py`; không copy thủ công trước khi script xác nhận `OPENAI_API_KEY` không rỗng và gateway chấp nhận key.
3. Script backup rồi copy nguyên trạng hai file (`auth.json` và `config.toml` luôn nằm cùng folder với `SKILL.md`) từ thư mục skill sang thư mục `.codex` của tài khoản đích:
   - `<skill-dir>\auth.json`
   - `<skill-dir>\config.toml`
4. Không cần khởi tạo hay cấu hình biến môi trường hệ thống cho Codex Extension.

Copy hai file vào thư mục `.codex` của tài khoản Windows đích. Với user hiện tại, lấy profile từ `$env:USERPROFILE`; với user khác, dùng profile path do hệ điều hành trả về hoặc do người dùng chỉ định. Không tự ghép ổ đĩa và tên user. Nếu cấu hình user hiện tại và `CODEX_HOME` đã được đặt, ưu tiên `CODEX_HOME`.

Phân biệt rõ yêu cầu cập nhật skill và yêu cầu áp dụng cấu hình:

- Nếu người dùng chỉ yêu cầu cập nhật/chỉnh sửa skill hoặc xem hướng dẫn, chỉ sửa và xác thực skill rồi dừng. Không tạo thư mục `.codex`, không backup, không copy file, không restart ứng dụng và không test gateway.
- Chỉ chạy thao tác copy khi người dùng yêu cầu rõ ràng việc áp dụng, cài đặt hoặc đồng bộ cấu hình lên tài khoản đích.
- `auth.json` có thể chứa thông tin xác thực: không đọc hoặc in nội dung, không đưa vào log/chat, và không commit file này nếu chứa secret.

### Windows PowerShell

Đặt biến `ALT_CODEX_SKILL_DIR` thành thư mục chứa `auth.json`, `config.toml` và `SKILL.md`, hoặc chạy PowerShell ngay trong thư mục skill. Mặc định `$targetProfile` là profile của user đang chạy; khi chọn tài khoản khác, lấy profile path thực tế từ hệ điều hành hoặc từ người dùng. Dùng script cài đặt để tránh bỏ sót `auth.json` hoặc copy vào sai `CODEX_HOME`:

```powershell
$sourceDir = if ($env:ALT_CODEX_SKILL_DIR) {
    (Resolve-Path -LiteralPath $env:ALT_CODEX_SKILL_DIR).Path
} else {
    (Get-Location).Path
}
if (-not (Test-Path -LiteralPath (Join-Path $sourceDir "SKILL.md") -PathType Leaf)) {
    throw "Không xác định được thư mục skill. Hãy đặt ALT_CODEX_SKILL_DIR hoặc chạy từ thư mục chứa SKILL.md."
}
$targetProfile = $env:USERPROFILE
$codexHome = if (($targetProfile -eq $env:USERPROFILE) -and $env:CODEX_HOME) {
    $env:CODEX_HOME
} else {
    Join-Path $targetProfile ".codex"
}
python (Join-Path $sourceDir "scripts\install_extension_config.py") `
  --source-dir $sourceDir `
  --target-dir $codexHome
```

Sau khi chạy, xác nhận script báo `OPENAI_API_KEY: present`, gateway HTTP 2xx và hai file đích hợp lệ; không đọc hoặc in giá trị trong `auth.json`. Báo cáo đường dẫn đích thực tế từ `$codexHome`, không giả định tên user hoặc ổ đĩa.

## Workflow Chuẩn

1. Kiểm tra phạm vi yêu cầu. Nếu người dùng chỉ yêu cầu cập nhật skill, sửa và xác thực skill rồi dừng, không áp dụng cấu hình. Nếu họ chỉ yêu cầu đổi model trên máy tính, thực hiện mục **Chỉ Đổi Model Trên Máy Tính** rồi dừng, không chạy workflow copy/đồng bộ phía dưới.
2. Khi được yêu cầu áp dụng, xác định hệ điều hành, tài khoản đích, profile đích và việc user hiện tại có dùng `CODEX_HOME` hay không.
3. Kiểm tra Codex Extension/Codex CLI đã được cài. Không tự cài extension nếu chưa biết đúng extension ID hoặc nguồn cài đặt.
4. Nếu người dùng yêu cầu dùng bộ file đi kèm skill, làm theo mục **Sao Chép Bộ File Mẫu** và copy đúng `auth.json`, `config.toml`.
5. Xác định đường dẫn user config và tạo thư mục `.codex` nếu chưa có.
6. Backup từng file đích đã tồn tại với timestamp trước khi copy hoặc sửa.
7. Chỉ khi người dùng yêu cầu chỉnh thủ công, cập nhật các khóa cần thiết trong `config.toml` và giữ nguyên cấu hình không liên quan.
8. Trường hợp cấu hình Codex Extension: xác nhận custom provider có `requires_openai_auth = true`, cập nhật `OPENAI_API_KEY` trong `auth.json`, rồi bắt buộc chạy `scripts/install_extension_config.py` để preflight, test `/v1/models`, backup và copy cả `auth.json`/`config.toml`; không cần tạo biến môi trường hệ thống. Đảm bảo không làm lộ key trong chat/log.
9. Thoát hoàn toàn và mở lại Antigravity/Codex Extension để app-server nhận đúng `CODEX_HOME`, provider config và credential.
10. Chạy một request thật bằng `codex exec`, xác nhận model trả lời thành công và log mới nhất không còn `401` hoặc request `/v1/responses` thiếu Authorization.

Khi đổi model, chuẩn hóa cách viết không phân biệt hoa/thường và chấp nhận dấu gạch ngang hoặc khoảng trắng như mô tả ở mục **Model Được Hỗ Trợ**. Chỉ ghi tên chính thức `GPT-5.6-sol`, `GPT-5.6-terra`, `GPT-5.6-luna` hoặc `GPT-6-astra` vào khóa `model`. Nếu không thể chuẩn hóa yêu cầu thành một trong bốn model này, thông báo danh sách model được hỗ trợ và dừng trước khi sửa cấu hình.

## Windows PowerShell

### Tạo thư mục và backup

```powershell
$codexHome = if ($env:CODEX_HOME) { $env:CODEX_HOME } else { Join-Path $env:USERPROFILE ".codex" }
$configPath = Join-Path $codexHome "config.toml"
New-Item -ItemType Directory -Force -Path $codexHome | Out-Null
if (Test-Path $configPath) {
    Copy-Item $configPath "$configPath.bak-$(Get-Date -Format yyyyMMdd-HHmmss)"
}
notepad $configPath
```

Thêm hoặc cập nhật mẫu cấu hình ở phần **Mục Tiêu**, không xóa các bảng khác.

### Lưu API key cho Codex Extension (Qua file auth.json)

Trường hợp cấu hình Codex Extension, cập nhật API key vào file `auth.json` trong thư mục skill (luôn nằm cùng folder với `SKILL.md`):

```json
{
  "OPENAI_API_KEY": "<API_KEY_CUA_BAN>"
}
```

Sau đó chạy `scripts/install_extension_config.py` để kiểm tra và copy `auth.json` cùng `config.toml` vào thư mục `.codex` (ví dụ `%USERPROFILE%\.codex`). **Không cần tạo biến môi trường hệ thống.**

Nếu dùng CLI riêng và muốn đăng nhập bằng biến môi trường, dùng đúng tên chuẩn `OPENAI_API_KEY`, không dùng `ALT_KEY`:

```powershell
$secureKey = Read-Host "Nhap API key" -AsSecureString
$plainKey = [System.Net.NetworkCredential]::new("", $secureKey).Password
[Environment]::SetEnvironmentVariable("OPENAI_API_KEY", $plainKey, "User")
Remove-Variable plainKey, secureKey
```

Đóng hoàn toàn Antigravity rồi mở lại nếu dùng phương pháp biến môi trường.

### Kiểm tra không lộ key

```powershell
if ([Environment]::GetEnvironmentVariable("OPENAI_API_KEY", "User")) { "OPENAI_API_KEY=set" } else { "OPENAI_API_KEY=missing" }
```

### Test gateway

Chạy trong cửa sổ PowerShell mới sau khi restart terminal:

```powershell
$key = [Environment]::GetEnvironmentVariable("OPENAI_API_KEY", "User")
curl.exe -sS -o NUL -w "%{http_code}`n" -H "Authorization: Bearer $key" --max-time 20 "https://codex.anhlaptrinh.vn/v1/models"
Remove-Variable key
```

## Linux

### Tạo thư mục và backup

```bash
codex_home="${CODEX_HOME:-$HOME/.codex}"
config_path="$codex_home/config.toml"
mkdir -p "$codex_home"
[ ! -f "$config_path" ] || cp -a "$config_path" "$config_path.bak-$(date +%Y%m%d-%H%M%S)"
${EDITOR:-nano} "$config_path"
```

### Lưu API key

Nhập ẩn, sau đó thêm dòng export vào file shell profile phù hợp mà không in key ra màn hình:

```bash
read -rsp 'Nhap API key: ' OPENAI_API_KEY; echo
export OPENAI_API_KEY
```

Để dùng sau khi đăng nhập lại, lưu bằng trình quản lý secret của hệ điều hành nếu có. Nếu buộc phải dùng shell profile, thêm thủ công `export OPENAI_API_KEY="..."` vào `~/.bashrc`, `~/.zshrc` hoặc file môi trường của desktop session, đặt quyền file `600`, và không commit file đó.

Antigravity mở từ desktop có thể không đọc `~/.bashrc`. Khi đó đặt biến trong môi trường desktop/login session hoặc khởi động Antigravity từ terminal đã có biến.

### Kiểm tra và test

```bash
[ -n "${OPENAI_API_KEY:-}" ] && echo 'OPENAI_API_KEY=set' || echo 'OPENAI_API_KEY=missing'
status=$(curl -sS -o /dev/null -w '%{http_code}' -H "Authorization: Bearer $OPENAI_API_KEY" --max-time 20 'https://codex.anhlaptrinh.vn/v1/models')
printf 'HTTP %s\n' "$status"
```

## macOS

File cấu hình giống Linux: `${CODEX_HOME:-$HOME/.codex}/config.toml`.

Antigravity mở từ Finder/Dock thường không nhận biến chỉ khai báo trong `~/.zshrc`. Dùng Keychain hoặc đặt biến cho GUI session. Cách tạm thời cho phiên đăng nhập hiện tại:

```bash
read -rsp 'Nhap API key: ' OPENAI_API_KEY; echo
launchctl setenv OPENAI_API_KEY "$OPENAI_API_KEY"
unset OPENAI_API_KEY
```

Sau đó thoát hoàn toàn và mở lại Antigravity. Kiểm tra tên biến mà không in key:

```bash
[ -n "$(launchctl getenv OPENAI_API_KEY)" ] && echo 'OPENAI_API_KEY=set' || echo 'OPENAI_API_KEY=missing'
```

Lưu ý: `launchctl setenv` không phải cơ chế lưu secret bền vững qua mọi lần đăng nhập. Với máy dùng lâu dài, ưu tiên macOS Keychain hoặc cơ chế quản lý môi trường doanh nghiệp của máy.

## Cập Nhật Config Không Phá Phần Khác

Nếu file đã có nhiều cấu hình, không thay toàn bộ file bằng một heredoc. Hãy sửa TOML có chủ đích:

- Đảm bảo `model_provider` trùng với ID của custom provider đang sửa; bộ file mẫu của skill dùng `model_provider = "router"` và `[model_providers.router]`.
- Đảm bảo `model` là model người dùng đã chọn trong danh sách hỗ trợ; mặc định là `GPT-5.6-sol`.
- Chuẩn hóa cách viết của người dùng về `GPT-5.6-sol`, `GPT-5.6-terra`, `GPT-5.6-luna` hoặc `GPT-6-astra`; không ghi model khác, tên chữ thường hoặc tên có khoảng trắng vào config.
- Đảm bảo `model_reasoning_effort = "medium"`, trừ khi người dùng yêu cầu mức khác.
- Đảm bảo `preferred_auth_method = "apikey"` và `cli_auth_credentials_store = "file"` để Extension/app-server đọc `auth.json` trong đúng `CODEX_HOME`.
- Tạo hoặc cập nhật `[model_providers.router]` với `name`, `base_url`, `wire_api = "responses"` và `requires_openai_auth = true`; chỉ thêm `env_key = "OPENAI_API_KEY"` khi người dùng chọn workflow biến môi trường CLI, không thêm để thay thế `auth.json` của Extension.
- Giữ nguyên mọi bảng `[projects."..."]`, MCP và cấu hình khác.

## Xử Lý Lỗi

### `env_key` chứa API key thật

Sai:

```toml
env_key = "sk-..."
```

Đúng cho CLI dùng biến môi trường:

```toml
env_key = "OPENAI_API_KEY"
```

Nếu phát hiện lỗi này, không nhắc lại giá trị key trong output. Hướng dẫn người dùng xoay vòng key nếu key từng bị lưu vào repo, log hoặc chat.

### HTTP `401`

- Với thông báo `API key required for remote API access`, coi đây là lỗi cài đặt và không báo hoàn tất: request tới `/v1/responses` không có bearer key.
- Kiểm tra `auth.json` trong đúng `CODEX_HOME` của process Antigravity có khóa `OPENAI_API_KEY` không rỗng; không chỉ kiểm tra file nằm cạnh `SKILL.md`.
- Kiểm tra block provider đang dùng có `requires_openai_auth = true`. Nếu key và gateway đều tốt nhưng log cho thấy Codex gửi `/v1/responses` không có `Authorization`, coi việc thiếu cờ này là nguyên nhân ưu tiên.
- Nếu chỉ có `ALT_KEY`, chuyển sang `OPENAI_API_KEY`/`auth.json`; `ALT_KEY` không được workflow Extension chuẩn sử dụng.
- Chạy lại `scripts/install_extension_config.py --check-only` hoặc cài lại không có `--skip-gateway-check`. Nếu `/models` vẫn `401`, key sai, hết hạn hoặc chưa được gateway cấp quyền.
- Sau khi sửa, thoát hoàn toàn Antigravity, mở lại, kiểm tra process có đúng `CODEX_HOME`, rồi thử một request `/v1/responses`; chỉ kiểm tra `/models` là chưa đủ để chứng minh phiên Extension đã nạp credential.
- `401` ở `chatgpt.com/backend-api/plugins/*`, `/wham/*` hoặc `/settings/user` là control-plane/plugin của ChatGPT; API-key auth có thể không được hỗ trợ ở các route đó và không chứng minh gateway ALT bị lỗi. Chỉ kết luận lỗi credential ALT khi endpoint trong `base_url` (ví dụ `/v1/models` hoặc `/v1/responses`) trả `401`.

### Ca Đã Xác Nhận Với Codex CLI v0.151.0 Ngày 2026-09-01

- `Codex.log` và lệnh `codex exec` cho thấy gateway cùng API key vẫn hoạt động, nhưng request do Codex gửi tới `https://codex.anhlaptrinh.vn/v1/responses` không có header `Authorization`.
- Nguyên nhân là custom provider `router` chưa có `requires_openai_auth = true`, nên Codex không nạp API key từ `auth.json` dù các khóa auth top-level đã được cấu hình.
- Cách sửa là thêm cờ vào đúng block provider trong cả user `config.toml` và file mẫu của skill, dừng đúng app-server cũ đã xác minh, rồi khởi động lại.
- Kiểm thử hoàn tất phải dùng request thật `codex exec`; ca này trả phản hồi thành công qua `GPT-5.6-sol` với HTTP `200` sau khi app-server nạp config mới.
- Bài học bắt buộc: test gateway trực tiếp chỉ chứng minh key/gateway sống; luôn kiểm tra thêm đường đi thực tế từ Codex app-server.

### HTTP `404`

Kiểm tra `base_url` có kết thúc bằng `/v1` và URL test là `/v1/models`. Không ghép thành `/v1/v1/models`.

### Không kết nối, timeout hoặc lỗi DNS

Kiểm tra internet, DNS, proxy/firewall, chứng chỉ TLS và khả năng truy cập `https://codex.anhlaptrinh.vn` từ chính máy đó.

### CLI chạy được nhưng extension không chạy

Extension có thể chạy trong môi trường GUI khác terminal. Kiểm tra biến môi trường của desktop session, đúng user home, `CODEX_HOME`, rồi restart toàn bộ Antigravity.

### Extension vẫn dùng provider cũ

- Xác nhận đang sửa user config đúng tài khoản.
- Tìm project-local config có thể ghi đè, nhưng không tự xóa.
- Reload window hoặc thoát hoàn toàn Antigravity rồi mở lại.
- Mở phiên chat Codex mới thay vì dùng phiên cũ.

## Tiêu Chí Hoàn Tất

- `config.toml` và `auth.json` được copy đúng vào thư mục `.codex` của user chạy Antigravity (`%USERPROFILE%\.codex` hoặc `$CODEX_HOME`).
- `auth.json` chứa `OPENAI_API_KEY` hợp lệ, không cần tạo biến môi trường hệ thống khi cấu hình extension.
- Provider trong `config.toml` chỉ tới `https://codex.anhlaptrinh.vn/v1`, dùng `wire_api = "responses"`, có `requires_openai_auth = true`, và model là một trong `GPT-5.6-sol`, `GPT-5.6-terra`, `GPT-5.6-luna` hoặc `GPT-6-astra`.
- Không có API key thật xuất hiện trong file log hay chat response.
- Antigravity/Codex Extension đã restart và `codex exec` thực tế trả phản hồi thành công, không còn `401`/thiếu Authorization.

## Mẫu Báo Cáo

```text
Đã cấu hình Codex Extension/Codex CLI dùng ALT Gateway trên <Windows|Linux|macOS>.
File cấu hình: <đường dẫn config.toml>.
Model: <GPT-5.6-sol|GPT-5.6-terra|GPT-5.6-luna|GPT-6-astra>.
Provider auth: requires_openai_auth=true.
API key được lưu trong `auth.json` dưới khóa `OPENAI_API_KEY`, không ghi vào config hoặc báo cáo.
Kiểm tra gateway: HTTP <mã>.
Kiểm thử Codex thực tế: `codex exec` thành công, `/v1/responses` HTTP 200.
Đã restart hoàn toàn Antigravity/app-server và mở phiên Codex mới.
```

## Bổ Sung: Telegram OpenClaw - Model Hiển Thị Cũ Hoặc Runtime Codex

Phần này bổ sung cho workflow cũ, không thay thế các quy tắc phía trên.

### Phạm Vi

- Áp dụng khi người dùng đổi model mặc định OpenClaw nhưng hỏi qua Telegram vẫn nhận câu trả lời kiểu `đang chạy 9r/codex` hoặc `/model status` hiển thị model mới nhưng runtime cũ.
- Chỉ sửa đúng VPS/runtime được người dùng chỉ định. Không tự sửa runtime phụ hoặc member VPS.
- Không bật reasoning/thinking mặc định nếu người dùng không yêu cầu. Với workflow này, giữ reasoning ở trạng thái tắt; không tự thêm `reasoningDefault: "on"` hoặc `thinkingDefault`.

### Phân Biệt Model Và Runtime

- `Current`/`Selected` là model được chọn, ví dụ `9r/GPT-5.6-luna`.
- `Active` là runtime thực thi, ví dụ `9r/codex` hoặc runtime `openclaw`.
- Câu trả lời tự nhận model cũ trên Telegram không đủ để kết luận. Phải đối chiếu log request thực tế có dạng `model-fetch ... provider=9r ... model=<model>`.
- Nếu muốn dùng runtime OpenClaw, đặt policy ở provider/model scope, không chỉ đổi `agents.defaults.model.primary`:

```json5
{
  "agents": {
    "defaults": {
      "models": {
        "9r/GPT-5.6-luna": {
          "agentRuntime": { "id": "openclaw" }
        }
      }
    }
  },
  "models": {
    "providers": {
      "9r": {
        "agentRuntime": { "id": "openclaw" }
      }
    }
  }
}
```

Không chép nguyên mẫu trên vào config nếu provider hiện tại không phải `9r`; luôn đọc provider/model đang dùng trước.

### Kiểm Tra Agent Telegram

1. Xác định binding Telegram tới agent nào:

```bash
openclaw_home="${OPENCLAW_HOME:-$HOME/.openclaw}"
openclaw_config="${OPENCLAW_CONFIG_PATH:-$openclaw_home/openclaw.json}"
openclaw_agents_dir="${OPENCLAW_AGENTS_DIR:-$openclaw_home/agents}"
jq '.bindings, .agents.list' "$openclaw_config"
```

2. Kiểm tra model mặc định và allowlist của đúng agent; không in `apiKey`, `auth.json`, cookie hoặc credential:

```bash
openclaw models status --agent <agent-id> --json
agent_models="$openclaw_agents_dir/<agent-id>/agent/models.json"
jq '{providers:(.providers|to_entries|map({id:.key,models:(.value.models|map(.id))}))}' \
  "$agent_models"
```

3. Kiểm tra session Telegram có đang ghim model cũ không. Nếu session entry có `model: "codex"` hoặc model cũ, gửi trong đúng chat:

```text
/model default
```

`/model default` xóa model override của session để session kế thừa model mặc định; `/new` chỉ tạo session mới và không nên được coi là thao tác xóa override model duy nhất.

4. Nếu cần kiểm tra session cụ thể mà không gửi tin thật ra Telegram, dùng session key đúng agent/channel qua CLI; không dùng `--deliver`:

```bash
openclaw agent --agent <agent-id> \
  --session-key 'telegram:direct:<chat-id>' \
  --message '/model default' --json
```

### Validate Và Restart Gateway

- Sau mỗi lần đổi model trong config OpenClaw đang hoạt động, luôn chạy validate rồi restart Gateway; không chỉ dựa vào hot reload.
- Script `set_alt_model.sh` thực hiện restart tự động. Nếu thao tác thủ công, chạy đủ ba lệnh:

```bash
openclaw config validate
openclaw gateway restart
openclaw gateway status
```

- Sau restart, tạo session Telegram mới hoặc gửi `/model default`, rồi kiểm tra lại `/model status` và log request.
- Không báo hoàn tất chỉ dựa trên file JSON. Tiêu chí đạt là log request mới nhất dùng đúng `provider=... model=<model-yêu-cầu>` và Telegram không còn tự nhận model cũ.

### Reasoning Mặc Định

- Không bật reasoning/thinking khi chỉ đổi model, trừ khi người dùng yêu cầu rõ.
- Giữ nguyên `reasoningDefault`/`thinkingDefault` nếu đã có; nếu workflow mới tạo cấu hình và người dùng không yêu cầu reasoning, để mặc định tắt.
- Khi báo cáo, tách riêng model, runtime và reasoning; không gộp `9r/codex` thành tên model nếu log cho thấy đó chỉ là runtime.

### An Toàn Và Bàn Giao

- Backup `openclaw.json`, catalog riêng của agent và session metadata nếu chuẩn bị sửa production.
- Không ghi API key thật vào skill. Khi đọc config để chẩn đoán, chỉ in provider, model, runtime và trạng thái `set/missing` của credential.
- Sau thay đổi quan trọng, ghi backup, lệnh validate, kết quả log request và tình trạng restart vào nhật ký VPS.

## Khắc Phục Lỗi "The extension couldn't load its resources" Trên Antigravity IDE

### Phạm Vi Và Nguyên Tắc Chẩn Đoán

Áp dụng khi Codex Extension trong Antigravity IDE hoặc VS Code Remote Server không mở được Sidebar/Panel và báo một trong các thông báo:

```text
Codex could not start - The extension couldn't load its resources
The extension couldn't load its resources
```

Đây là thông báo giao diện chung, không phải lúc nào cũng do CSP. Luôn đọc `Codex.log` mới nhất rồi phân loại trước khi sửa:

- **Nhánh A - Webview timeout/CSP:** có `CodexWebviewProvider] Webview did not finish starting ... role=sidebar`; `webview/index.html` còn `crossorigin` hoặc `modulepreload`; entry JS còn polyfill `fetch(e.href,n)` chưa được bảo vệ.
- **Nhánh B - `codex app-server` chết:** có `Fatal error`, `Codex app-server process exited unexpectedly` hoặc `Last CLI error`. Sửa lỗi app-server/plugin/config được ghi ngay sau đó; không mặc định vá Webview.
- **Nhánh C - provider/xác thực/kết nối:** có `401`, `404`, timeout, DNS hoặc provider/model lỗi. Dùng các mục xử lý gateway/config phía trên; patch Webview không giải quyết nhóm này.
- Nếu log có nhiều nhánh, xử lý từng lỗi theo thứ tự thời gian và luôn kiểm tra log của lần reload mới nhất.

### Ca Thực Tế Đã Xác Nhận Ngày 2026-08-08

- Log `$HOME/.antigravity-ide-server/data/logs/20260808T053622/exthost2/openai.chatgpt/Codex.log` có `Webview did not finish starting extensionVersion=26.730.61309 role=sidebar`.
- Thư mục thực tế là `$HOME/.antigravity-ide-server/extensions/openai.chatgpt-26.5730.61309-linux-x64`. Chuỗi version trong log và tên folder có thể khác cách biểu diễn; không tự ghép đường dẫn từ `extensionVersion`, phải dò trên filesystem.
- Đã backup `webview/index.html` và `webview/assets/index-BC1ECcH_.js`, bỏ `crossorigin`/`modulepreload`, rồi đổi polyfill thành `try{fetch(e.href,n).catch(()=>{})}catch(_){}`.
- Đã kiểm tra config user dùng provider `router` trỏ tới ALT Gateway mà không in `auth.json`, dọn tiến trình app-server cũ và yêu cầu chạy `Developer: Reload Window`.
- Cùng thông báo giao diện vẫn có thể đi kèm lỗi khác trong log, ví dụ plugin manifest có `defaultPrompt` dài quá giới hạn. Lỗi plugin là nhánh riêng và không được coi là bằng chứng rằng patch CSP thất bại.

### 1. Resolve Đường Dẫn Thực Tế

Không hardcode `/root`. Dùng home của user đang chạy Antigravity hoặc biến override đã được xác minh:

```bash
server_home="${ANTIGRAVITY_SERVER_HOME:-$HOME/.antigravity-ide-server}"
logs_root="$server_home/data/logs"
extensions_root="$server_home/extensions"

latest_log="$(
  find "$logs_root" -type f -path '*/openai.chatgpt/Codex.log' \
    -printf '%T@ %p\n' 2>/dev/null |
    sort -nr | head -n 1 | cut -d' ' -f2-
)"

ext_dir="$(
  find "$extensions_root" -mindepth 1 -maxdepth 1 -type d \
    -name 'openai.chatgpt-*-linux-x64' -printf '%T@ %p\n' 2>/dev/null |
    sort -nr | head -n 1 | cut -d' ' -f2-
)"

test -f "$latest_log" || { echo "Không tìm thấy Codex.log" >&2; exit 1; }
test -d "$ext_dir/webview" || { echo "Không tìm thấy webview extension" >&2; exit 1; }
printf 'Codex log: %s\nExtension: %s\n' "$latest_log" "$ext_dir"
```

Chọn extension theo filesystem/mtime và kiểm tra `package.json`; không dùng `ls ... | tail -n 1` vì thứ tự chuỗi version có thể chọn nhầm bản.

### 2. Đọc Log Và Chọn Đúng Nhánh

```bash
rg -n \
  'Webview did not finish starting|Fatal error|app-server process exited|Last CLI error|401|404|timeout|CSP|Content-Security' \
  "$latest_log" | tail -n 100
```

Chỉ đi tiếp nhánh patch Webview khi log và file tài nguyên cùng khớp. Kiểm tra dấu hiệu mà không in toàn bộ bundle:

```bash
index_html="$ext_dir/webview/index.html"
entry_src="$(rg -o 'src="\./assets/index-[^"]+\.js"' "$index_html" | head -n 1 | cut -d'"' -f2)"
test -n "$entry_src" || { echo "Không xác định được entry JS" >&2; exit 1; }
index_js="$ext_dir/webview/${entry_src#./}"

test -f "$index_js" || { echo "Không tìm thấy: $index_js" >&2; exit 1; }
rg -n 'crossorigin|modulepreload' "$index_html" || true
rg -n -F 'fetch(e.href,n)' "$index_js" || true
rg -n -F 'try{fetch(e.href,n).catch(()=>{})}catch(_){}' "$index_js" || true
```

Nếu bundle của version mới không còn đúng signature `fetch(e.href,n)`, dừng để phân tích version đó; không fuzzy-replace mọi lệnh `fetch()`.

### 3. Backup Trước Khi Patch

```bash
stamp="$(date -u +%Y%m%dT%H%M%SZ)"
html_backup="$index_html.bak-$stamp"
js_backup="$index_js.bak-$stamp"

cp -p "$index_html" "$html_backup"
cp -p "$index_js" "$js_backup"
printf 'HTML backup: %s\nJS backup: %s\n' "$html_backup" "$js_backup"
```

Không ghi đè file `.bak` cũ và không copy bundle đã patch từ version extension khác.

### 4. Patch `webview/index.html` Có Kiểm Soát

Loại bỏ thuộc tính `crossorigin` và thẻ preload module. Lệnh dưới đây idempotent: chạy lại khi đã patch sẽ không thêm nội dung mới.

```bash
python3 - "$index_html" <<'PY'
from pathlib import Path
import re
import sys

path = Path(sys.argv[1])
text = path.read_text(encoding="utf-8")
patched = re.sub(
    r"\s+crossorigin(?:=(?:\"[^\"]*\"|'[^']*'))?",
    "",
    text,
    flags=re.IGNORECASE,
)
patched = re.sub(
    r"\s*<link\b(?=[^>]*\brel=(?:\"modulepreload\"|'modulepreload'))[^>]*>",
    "",
    patched,
    flags=re.IGNORECASE,
)
if patched != text:
    path.write_text(patched, encoding="utf-8")
    print("Patched index.html")
else:
    print("index.html already patched or signature not present")
PY
```

### 5. Bảo Vệ `fetch()` Polyfill Trong Entry JS

Chỉ thay đúng một signature đã biết. Nếu không phải đúng một lần, script dừng để tránh làm hỏng bundle minified:

```bash
python3 - "$index_js" <<'PY'
from pathlib import Path
import sys

path = Path(sys.argv[1])
text = path.read_text(encoding="utf-8")
unsafe = "fetch(e.href,n)"
guarded = "try{fetch(e.href,n).catch(()=>{})}catch(_){}"

if guarded in text:
    print("Entry JS already patched")
    raise SystemExit(0)

count = text.count(unsafe)
if count != 1:
    raise SystemExit(f"Expected exactly one known fetch signature, found {count}; stop for manual analysis")

path.write_text(text.replace(unsafe, guarded, 1), encoding="utf-8")
print("Patched entry JS")
PY
```

### 6. Xác Minh Patch Trước Khi Reload

```bash
if rg -n 'crossorigin|modulepreload' "$index_html"; then
  echo "index.html vẫn còn marker cần kiểm tra" >&2
  exit 1
fi

rg -n -F 'try{fetch(e.href,n).catch(()=>{})}catch(_){}' "$index_js" >/dev/null || {
  echo "Không tìm thấy fetch guard" >&2
  exit 1
}

stat -c '%a %U:%G %s %n' "$index_html" "$index_js" "$html_backup" "$js_backup"
```

Không coi việc file đã đổi là đủ. Sau reload phải kiểm tra Webview thực sự mount và log mới không lặp lại timeout.

### 7. Xử Lý App-Server Cũ Một Cách Có Phạm Vi

Trước tiên chỉ liệt kê tiến trình:

```bash
pgrep -af 'codex.*app-server|openai.chatgpt.*codex' || true
```

- Chỉ `kill <PID>` sau khi xác minh PID thuộc extension/app-server cũ hoặc executable trỏ vào folder extension không còn tồn tại.
- Không dùng `pkill -f codex` mặc định vì có thể dừng Codex CLI hiện tại, phiên khác của người dùng hoặc tiến trình không liên quan.
- Nếu nghi socket cũ, kiểm tra `${CODEX_HOME:-$HOME/.codex}/ipc/ipc.sock` và process sở hữu trước; không xóa socket khi vẫn có process đang listen.

### 8. Kiểm Tra Config Mà Không Lộ Secret

Lỗi Webview có thể độc lập với provider. Chỉ xác minh các khóa cần thiết; không rewrite `config.toml` nếu log không chỉ ra lỗi config và tuyệt đối không in `auth.json`:

```bash
codex_home="${CODEX_HOME:-$HOME/.codex}"
config_path="$codex_home/config.toml"
auth_path="$codex_home/auth.json"

test -f "$config_path" && \
  rg -n '^(model_provider|model|model_reasoning_effort|preferred_auth_method)\s*=|^\[model_providers\.[^]]+\]|^(name|base_url|wire_api|requires_openai_auth|env_key)\s*=' \
    "$config_path"

if test -s "$auth_path"; then
  stat -c 'auth.json=present mode=%a owner=%U:%G' "$auth_path"
else
  echo 'auth.json=missing-or-empty'
fi
```

Provider có thể là `router` hoặc `alt` tùy cấu hình hiện tại. Không đổi provider, model, reasoning hoặc auth method chỉ vì Webview timeout.

### 9. Reload Và Xác Minh Kết Quả

1. Mở Command Palette bằng `Ctrl+Shift+P` hoặc `F1`.
2. Chạy `Developer: Reload Window`.
3. Mở Codex Sidebar và chờ UI mount.
4. Tìm `Codex.log` mới nhất theo bước 1; xác nhận không còn `Webview did not finish starting` trong lần khởi động mới.
5. Nếu xuất hiện `Fatal error` mới, chuyển sang nhánh app-server thay vì lặp lại patch.

### Nhánh Riêng: App-Server Hoặc Plugin Manifest Lỗi

Ví dụ log:

```text
Codex app-server process exited unexpectedly
Last CLI error: ... manifest ... defaultPrompt[0]: prompt must be at most 128 characters
```

Khi gặp nhánh này:

- Xác định lỗi đầu tiên trước khi process thoát, không chỉ lấy câu cuối cùng trong log.
- Nếu log trỏ vào `$CODEX_HOME/.tmp/plugins/...`, coi đó là bản staging/cache; tìm plugin/skill nguồn tương ứng trước khi sửa.
- Backup manifest nguồn, rút gọn prompt vi phạm về tối đa 128 ký tự, validate plugin/skill rồi reload lại.
- Không dùng patch `crossorigin`/`fetch()` để chữa lỗi manifest. Chỉ giữ patch Webview nếu nhánh A cũng được xác nhận độc lập.

### Rollback

Nếu Webview lỗi nặng hơn hoặc bundle không còn load, khôi phục đúng hai backup cùng timestamp:

```bash
cp -p "$html_backup" "$index_html"
cp -p "$js_backup" "$index_js"
```

Sau rollback, chạy `Developer: Reload Window` và đọc log mới. Không rollback bằng file backup của version extension khác.

### Lưu Ý Sau Khi Extension Tự Cập Nhật

- Extension update có thể tạo folder hash/version mới và làm mất patch cũ.
- Dò lại extension đang active, đọc log và kiểm tra signature từ đầu; không tự động chép `index.html` hoặc bundle JS của bản cũ sang bản mới.
- Nếu upstream đã sửa CSP/polyfill, không áp dụng patch nữa.

### Tiêu Chí Hoàn Tất

- Đã phân loại đúng Webview timeout, app-server/plugin hoặc provider/auth.
- Nếu dùng custom provider, đã xác nhận `requires_openai_auth = true` và chạy request thật bằng `codex exec` sau khi app-server restart.
- Đã backup đúng file trước khi sửa và có đường dẫn rollback.
- `index.html` không còn `crossorigin`/`modulepreload` khi nhánh A yêu cầu.
- Entry JS có fetch guard đúng signature, không sửa các `fetch()` khác.
- Codex Sidebar mount sau `Developer: Reload Window` và log mới không lặp timeout.
- Không in hoặc ghi API key/token/cookie/password/private key vào skill, log hay báo cáo.
- Sau thay đổi quan trọng trên VPS, cập nhật `/root/_Second_AI_Brain/06_Nhat_Ky_Thay_Doi.md`.
