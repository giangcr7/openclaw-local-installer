# Member VPS v6 Template

V6 inherits the clean-install and fast Golden image workflow from V5. It adds a
versioned module catalog, a default complete assistant profile and optional
member modules. Customer history, runtime databases, OpenClaw state, Telegram
state, logs and credentials remain excluded from the release. Run
`bash verify-release-clean.sh` before publishing or using a future release.

Golden image OpenClaw mới, kế thừa baseline môi trường V2 đã làm sạch cho cài
member mới. Bản release không chứa cấu hình, token, session, lịch sử, database
hoặc dữ liệu runtime của bất kỳ member nào.

## Thành phần mặc định

- Image `member-vps-golden:20261007`, dựa trên `vps-user-env:latest`.
- OpenClaw `2026.9.7` được đóng sẵn trong image và native installer.
- Dữ liệu từng member được lưu ngoài release tại `/root/Apps/member_vps/docker-users/data/<member>`; template V5 không chứa customer state.
- V5 không mang theo lịch sử mẫu ANVI hoặc `conversations.db`; các thư mục runtime chỉ giữ `.gitkeep` khi cần giữ cấu trúc.
- Mỗi member có hai thư mục persistent: `root` được mount vào `/root`, `home` được mount vào `/home/<member>`.
- Installer bung `v2-derived-root-template.tar.gz` và `v2-derived-home-template.tar.gz` vào hai thư mục persistent để giữ đủ baseline V2.
- Ứng dụng và cấu hình riêng của Nhà máy sản xuất video đã được loại khỏi baseline V5.
- Telegram group policy mặc định là open: mọi group mà bot tham gia đều không bắt mention và mọi sender được cấp `exec/process`; không hardcode group ID vào template.
- Trước khi bàn giao bot cho group, bắt buộc vào BotFather → `/setprivacy` → chọn bot → `Disable`; đây là quyền do Telegram quản lý, không có Bot API/OpenClaw nào tự bật thay được.
- Bộ đọc tài liệu hỗ trợ Word `.doc/.docx/.docm`, Excel `.xls/.xlsx` và PowerPoint `.ppt/.pptx`; V5 cài `antiword`, `catdoc`, `xls2csv` và `catppt` cho định dạng Office cũ.
- OpenClaw, Node, FFmpeg và Supervisor từ base image.
- Telegram/OpenClaw được cấu hình riêng cho từng khách.
- Profile `basic-assistant-full` được nạp khi container khởi động. Profile này
  gồm các module nền tảng đã đóng sẵn trong image, không cần tải dependency khi
  tạo member.
- Module nâng cao được phát hành riêng trong cùng catalog và chỉ được bật khi
  member cần; chọn bằng `profile` hoặc `modules` trong settings riêng của
  member.
- PDF scan được hỗ trợ OCR tiếng Việt/Anh bằng Tesseract; bot phải OCR và đối chiếu theo số trang trước khi kết luận nội dung pháp lý.
- API key lưu trong file mode `600` và chỉ được export vào tiến trình gateway; không ghi giá trị thật vào `openclaw.json`.
- Container dùng `--restart unless-stopped`, nên không cần mở Docker Desktop thủ công sau khi máy khởi động nếu Docker Desktop đã bật auto-start.

## Cài member mới

### Native Windows (không Docker)

Đây là lựa chọn tối ưu khi cài qua UltraViewer trên máy khách. Chạy PowerShell bằng **Run as Administrator**; script cài Node.js nếu thiếu, cài cố định OpenClaw `2026.9.7`, tạo Windows daemon/service, lưu cấu hình trong `%USERPROFILE%\.openclaw` và không gọi Docker Desktop.

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\install-native-windows.ps1 -Name member01 -OwnerIds '123456789,987654321' `
  -GroupId '-1001234567890' -BaseUrl 'https://codex.anhlaptrinh.vn/v1' -Model 'gpt-6.1-sol' -DryRun
```

Bỏ `-DryRun` để cài thật. Script hỏi Bot Token/API key bằng ô nhập bảo mật và không in chúng ra màn hình.

### Cài bằng một link

Sau khi upload `native-full-bundle.tar.gz` lên GitHub Release/CDN, khách không cần nhận file thủ công. Gửi `bootstrap-native.ps1` hoặc lệnh bootstrap kèm URL archive và SHA256 của đúng phiên bản. Bootstrap tải, kiểm tra checksum, giải nén tạm rồi mới chạy installer; không đặt secret vào URL.

Bootstrap dùng chung bundle cho cả ba hệ điều hành:

- Windows: `bootstrap-native.ps1` → Windows daemon.
- macOS: `bootstrap-native.sh` → launchd/local gateway, runtime `/var/root/.openclaw`.
- Linux: `bootstrap-native.sh` → systemd/local gateway, runtime `/root/.openclaw`.

Trên macOS/Linux phải chạy bằng `root` hoặc `sudo -H`; trên Windows phải chạy PowerShell Administrator. Mỗi launcher tự cài dependency nền tảng tương ứng, cài profile core/module đã chọn, áp dụng owner/approval/Full Exec, validate và kiểm tra skill. Có thể dùng `--full-bundle` hoặc `-FullBundle` để khôi phục cách đồng bộ toàn bộ 183 skill.

Bộ native đầy đủ gồm `native-full-bundle.tar.gz`. Khi gửi cho khách, giải nén cùng thư mục với script; bộ này chứa 183 skill đã làm sạch và catalog module. Installer mặc định chỉ cài profile/module được chọn; full bundle vẫn giữ làm phương án recovery/compatibility. Cả hai chế độ đều áp dụng owner policy/approval, cấu hình Full Exec và chạy `openclaw skills check` trước khi restart gateway.

Native Windows là bộ cài cho máy khách không có Docker. Script tự chuẩn bị Node.js, Python 3.12 và FFmpeg (nếu winget có sẵn), giữ đủ owner allowlist, group allowlist và Full Exec `gateway/full` (OpenClaw mới biểu diễn quyền tương đương `security=full`, `ask=off` bằng `mode=full`); gateway vẫn chỉ bind loopback. Golden Docker vẫn giữ cho VPS/phát triển; hai môi trường không dùng chung runtime hoặc credential.

### Windows/Docker Desktop

Dùng `install-member-local.ps1`. Image Golden đã chứa module; script chỉ import image một lần, bơm settings riêng và khởi động container. Không giải nén archive member cũ.

```powershell
.\install-member-local.ps1 -Name member01 -TelegramToken $tg -ProviderApiKey $key `
  -BaseUrl 'https://codex.anhlaptrinh.vn/v1' -Model 'gpt-6.1-sol' `
  -OwnerIds '123456789,987654321' -GroupId '-1001234567890'
```

Chạy thử trước bằng cách thêm `-DryRun`.

### Bắt buộc sau khi tạo bot Telegram

Thực hiện một lần cho mỗi bot mới:

1. Mở cuộc trò chuyện với `@BotFather`.
2. Gửi `/setprivacy`.
3. Chọn đúng bot member vừa tạo.
4. Chọn `Disable`.
5. Thêm bot vào group và cấp quyền đọc tin nhắn nếu Telegram yêu cầu.
6. Kiểm tra bằng `openclaw channels status --probe`; trạng thái cần có `connected`, `works` và `audit ok`.

OpenClaw đã mở policy cho mọi group, nhưng không thể thay đổi Privacy Mode của BotFather bằng token bot. Nếu bước này chưa hoàn tất, Telegram sẽ không chuyển phần lớn tin nhắn group không mention cho bot.

1. Copy `settings.example.json` thành một file riêng bên ngoài release, ví dụ `customer.json`.
2. Điền `member`, Telegram token, owner IDs, provider base URL/API key/model.
3. Chạy dry-run:

```bash
bash install.sh /path/customer.json dry-run
```

4. Cài thật:

```bash
bash install.sh /path/customer.json
```

Không đưa file settings thật vào Git, archive, Docker image hoặc chat log.

## Module V6

Liệt kê module trong một member:

```bash
docker exec user-MEMBER member-module list
```

Kiểm tra profile/module trước khi cài:

```bash
docker exec user-MEMBER member-module validate
```

Settings riêng có thể chọn profile và thêm module:

```json
{
  "profile": "zalo",
  "modules": ["google-drive-sync"]
}
```

Profile mặc định là `basic-assistant-full`. Module `zalo-personal` được cài mặc
định trên Docker/Linux và sau khi tạo user sẽ tự đăng ký kiểm tra Zalo không
phản hồi, Shared Watchdog Center, Gateway/Supervisor recovery và Resource/OOM
Guard. Khi Zalo chưa onboarding, chưa quét QR hoặc đang pairing, watchdog ghi
`not_configured` và không restart. Bộ kiểm tra chỉ tự phục hồi khi channel đã
được cấu hình nhưng thật sự unhealthy; không gửi tin nhắn thật và không đụng
credential, QR, cookie hoặc session.
Các profile có sẵn gồm `social`, `zalo`, `video` và `business`. Zalo vẫn cần
QR/onboarding và credential riêng; không đặt secret trong module hoặc image.
Metadata hiện chỉ cho phép `zalo-personal` trên Docker/Linux. Máy Windows
native không được coi là đã hỗ trợ Zalo Personal chỉ vì cài được skill; cần
transport Zalo tương thích Windows riêng trước khi bật cho khách Windows.

### Native local module manager

V6 native local now includes a cross-platform module manager. A new local
installation installs the selected core profile by default and stores the
catalog and clean skill payload under the member's OpenClaw home. Use
`--full-bundle` when the whole native bundle is intentionally required for
recovery or compatibility.

After an existing native installation receives the manager, modules can be
added directly on that machine without Docker:

```bash
bash /path/to/native/install-module-manager-unix.sh
member-module-native validate --module zalo-personal
member-module-native install --module zalo-personal
member-module-native list
```

On Windows, run PowerShell as Administrator:

```powershell
.\native\install-module-manager-windows.ps1
& "$env:USERPROFILE\.openclaw\module-manager.ps1" -Command validate -Module zalo-personal
& "$env:USERPROFILE\.openclaw\module-manager.ps1" -Command install -Module zalo-personal
```

The native manager keeps `modules.json`, `module-state/`, a catalog and a
clean cached skill source under the local OpenClaw home. It validates platform,
dependencies and payloads before install, then attempts a Gateway restart after
an install. Modules that require external credentials still need separate
onboarding after installation.

## Thêm module cho các lần cài sau

Module chỉ được promote khi đã làm sạch secret, session và dữ liệu khách:

```bash
bash docker/promote-module.sh \
  --container user-MEMBER \
  --id ten-module \
  --source /root/Apps/ten-module
```

Sau đó build lại Golden:

```bash
bash build-golden.sh 20261005
```

Bản build mới giữ module nền trong profile `basic-assistant-full`; module nâng cao
chỉ được cài cho member có trong settings/profile tương ứng. Member cũ không tự
đổi vì dữ liệu của họ nằm trong volume riêng; muốn nâng cấp phải dùng quy trình
upgrade có kiểm soát.

## Module format

```text
modules/ten-module/
├── module.json
├── skills/       # copy vào /root/.openclaw/workspace/skills/
├── apps/         # copy vào /root/Apps/
└── supervisor/   # tùy chọn, copy supervisor .conf
```

`module.json` bắt buộc có `id` và `version`. Không đặt token, API key, cookie, session, credential, database runtime hoặc dữ liệu khách trong module.

## Zalo Personal

V5 có sẵn quy trình onboarding Zalo Personal nhưng không chứa session, QR,
cookie, pairing code hay danh tính owner của member nào. Cài sau trên đúng
container bằng [zalo/README.md](zalo/README.md):

1. Chạy preflight và backup.
2. Cài `@openclaw/zalouser` đúng release với OpenClaw core.
3. Cấu hình account `default`, binding vào agent `main`, DM/group policy.
4. Gửi QR qua Telegram owner để người dùng quét trên điện thoại.
5. Duyệt pairing hoặc thêm owner Zalo sau khi xác minh ID.
6. Đăng ký Gateway/Zalo/resource watchdog và chạy các probe xác nhận. Luồng
   mặc định dùng `openclaw-zalo-no-response` → `shared-watchdog-center` →
   `recover-openclaw-member-gateway` (Supervisor guard) →
   `member-vps-resource-oom-guard`.

Không copy profile Zalo từ member khác. Không tự động quét QR hoặc gửi tin
Zalo thật trong bước healthcheck. Khi cần cấp full owner và mở group không cần
mention, dùng script trong `zalo/` với các ID đã xác minh của member đó.
