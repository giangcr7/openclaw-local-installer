# V6 modules

V6 separates the member runtime into a stable core, default core modules and
optional modules. Every module is versioned and must contain a `module.json`.

Core modules are selected by `profiles/basic-assistant-full.json` and are
installed from the image without downloading dependencies during member
provisioning. Optional modules are selected per member through the member
settings file or a profile.

Modules contain clean code, skills, scripts and service templates only. Native
local installations use the same catalog through `native/module-manager.py`,
`native/module-manager.sh` and `native/module-manager.ps1`; Docker keeps using
the container-side `member-module`. Both managers write per-member state and
never share credentials.

Modules contain clean code, skills, scripts and service templates only. They
must never contain credentials, tokens, cookies, browser profiles, sessions,
databases, logs, generated media or customer history. The native skill mapping
used by local installations is stored in `native/module-skills.json`.
