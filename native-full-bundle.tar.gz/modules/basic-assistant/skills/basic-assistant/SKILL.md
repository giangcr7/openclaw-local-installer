---
name: basic-assistant
description: Core assistant behavior for a new OpenClaw member runtime.
---

# Basic Assistant

Use the configured OpenClaw provider and Telegram channel to assist the member.
Keep customer credentials and runtime state outside this module.
